package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import java.io.File;
import java.nio.file.Files;
import java.time.Duration;
import java.util.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;



public class IshaHomesPage {
    WebDriver driver;
    WebDriverWait wait;
    Actions actions;

    public IshaHomesPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        this.actions = new Actions(driver);
    }

    public void closePopups() {
        try {
            WebElement closeLive = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"livchat_close\"]/b")));
            closeLive.click();
            WebElement closeChat = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"indicator-close\"]/a")));
            closeChat.click();
     
        } catch (Exception e) {
            System.out.println("⚠️ Popups not found or already closed.");
        }
    }
    
    public void close() {
    	try {
    		WebElement closeChattt = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"indicator-close\"]/a")));
            closeChattt.click();
    	}
    	catch(Exception e) {
    		System.out.println("No popups");
    	}
    }
    
    
    public void navigateToCompletedProjects() {
        List<WebElement> navLinks = driver.findElements(By.className("nav-link"));
        for (WebElement link : navLinks) {
            if (link.getText().trim().equalsIgnoreCase("Completed Projects")) {
                wait.until(ExpectedConditions.elementToBeClickable(link)).click();
                break;
            }
        }
    }
    
    public void scrollToContactUs() throws InterruptedException {
    	Thread.sleep(1000);
        WebElement contactUsSection = driver.findElement(By.xpath("/html/body/footer/div/section/div/div/div/section[1]/div/div[2]/div/div[2]/div/ul/li[1]/a/span")); // or use XPath/CSS if needed
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'start'});", contactUsSection);
    }
    
    public void scrollToEmail() throws InterruptedException {
    	Thread.sleep(1000);
        WebElement EmailSection = driver.findElement(By.xpath("//*[@id=\"main-wrap\"]/div/section[3]/div/div[1]/div/div[1]/div/div/div/div/p[1]/b")); // or use XPath/CSS if needed
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({behavior: 'smooth', block: 'start'});", EmailSection);
    }

    public Set<String> getUniqueProjectNames() throws InterruptedException {
       // wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//*[@role='link']")));
    	Thread.sleep(10000);
        List<WebElement> projects = driver.findElements(By.xpath("//*[@role='link']"));

        Set<String> names = new LinkedHashSet<>();
        for (WebElement project : projects) {
            String name = project.getText().trim();
            if (!name.isEmpty()) names.add(name);
        }
        return names;
    }

    public void clickEnquireNow() {
        WebElement enquireNowBtn = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Enquire Now")));
        actions.moveToElement(enquireNowBtn).click().perform();
    }

    public boolean isContactInfoDisplayed() {
        List<WebElement> contactElements = driver.findElements(By.xpath("//*[contains(text(),'Contact Info')]"));
        return !contactElements.isEmpty() && contactElements.get(0).isDisplayed();
    }

    public void navigateToContactUs() throws InterruptedException {
    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/footer/div/section/div/div/div/section[1]/div/div[2]/div/div[2]/div/ul/li[1]/a"))).click();
        //WebElement moreDropdown = driver.findElement(By.xpath("/html/body/footer/div/section/div/div/div/section[1]/div/div[2]/div/div[2]/div/ul/li[1]/a"));
        //moreDropdown.click();
        //wait.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/footer/div/section/div/div/div/section[1]/div/div[2]/div/div[2]/div/ul/li[1]/a"))).click();
    }

    public String getContactEmail() {
        WebElement email = driver.findElement(By.xpath("//*[@id=\"main-wrap\"]/div/section[3]/div/div[1]/div/div[1]/div/div/div/div/p[5]/a"));
        return email.getText();
    }

    public void captureScreenshot(String path) {
        try {
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            File dest = new File(System.getProperty("user.dir") + "/" + path);
            Files.copy(src.toPath(), dest.toPath());
            System.out.println("📸 Screenshot saved at: " + path);
        } catch (Exception e) {
            System.out.println("❌ Screenshot failed: " + e.getMessage());
        }
    }
}
