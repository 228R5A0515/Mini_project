package utils;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
    Properties prop;

    public ConfigReader() {
        try {
            prop = new Properties();
            String path = System.getProperty("user.dir") + "/config/config.properties";
            FileInputStream fis = new FileInputStream(path);
            prop.load(fis);
        } catch (Exception e) {
            System.out.println("❌ Failed to load config: " + e.getMessage());
        }
    }

    public String getProperty(String key) {
        return prop.getProperty(key);
    }
}
