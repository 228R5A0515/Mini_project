package tests;

import org.testng.annotations.Test;
import pages.IshaHomesPage;
import java.util.Set;

public class EnquiryTest extends BaseTest {
    IshaHomesPage page;

    @Test
    public void runTest() {
        page = new IshaHomesPage(driver);

        try {
            page.closePopups();
            page.navigateToCompletedProjects();
            Thread.sleep(5000);
            page.close();
            Set<String> projects = page.getUniqueProjectNames();
            System.out.println("✅ Unique Completed Projects: " + projects.size());
            int count = 1;
            for (String name : projects) {
                if (count <= 5) {
                    System.out.println(count++ + ". " + name);
                } else break;
            }

            //page.clickEnquireNow();

            if (page.isContactInfoDisplayed()) {
                System.out.println("✅ Contact Info text is displayed.");
            } else {
                System.out.println("❌ Contact Info is not displayed.");
            }
            page.scrollToContactUs();
            Thread.sleep(5000);
            page.navigateToContactUs();
            
            Thread.sleep(5000);
            page.close();
            
            Thread.sleep(3000);
            page.scrollToEmail();
            Thread.sleep(5000);
            String email = page.getContactEmail();
            System.out.println("📧 Contact Email: " + email);

            page.captureScreenshot("screenshot/result.png");

        } catch (Exception e) {
            System.out.println("❌ Test failed: " + e.getMessage());
        }
    }
}
