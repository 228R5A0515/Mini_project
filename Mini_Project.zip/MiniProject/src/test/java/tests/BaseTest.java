package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.*;
import utils.BrowserFactory;

public class BaseTest {
    protected WebDriver driver;

    @Parameters("browser")
    @BeforeClass
    public void setup(String browser) {
        driver = BrowserFactory.getDriver(browser);
        driver.manage().window().maximize();
        driver.get("https://ishahomes.com");
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) driver.quit();
    }
}
